MDB 5 Vue

Version: PRO Essential 2.0.0

___________________________________

Early Access Disclaimer: 

This Early Access grants you access to a UI Kit that is still in development.
 
It is an unfinished UI Kit, which means you may encounter usability issues, and lack of support as this version is not yet available on our forum.

While Early Access releases aren't ready to be used to build production solutions, they're at a stage where you can test and tinker with an implementation & provide feedback.

The schedule for all upcoming features of this UI Kit can be found in release roadmap - https://mdbootstrap.com/docs/b5/roadmap/

___________________________________

Documentation:
https://mdbootstrap.com/docs/b5/vue/

Getting started:
https://mdbootstrap.com/docs/b5/vue/pro/installation/

FAQ
https://mdbootstrap.com/docs/b5/vue/pro/#section-faq

ChangeLog
https://mdbootstrap.com/docs/b5/vue/changelog/

License:
https://mdbootstrap.com/general/license/

________________________

Facebook: https://facebook.com/mdbootstrap
Twitter: https://twitter.com/MDBootstrap
Dribbble: https://dribbble.com/mdbootstrap

Contact:
contact@mdbootstrap.com
