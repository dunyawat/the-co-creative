export default {
  mounted(el, binding) {
    el.intersect = {
      visible: false,
      container: window,
      lostVisibility: null,
    };

    if (binding.value) {
      el.intersect = {
        ...el.intersect,
        ...binding.value,
      };
    }

    if (
      el.parentNode.style.overflowY === "scroll" ||
      (el.parentNode.style.overflowY === "auto" && binding.arg === "container")
    ) {
      el.intersect.container = el.parentNode;
    }

    el.intersect.isVisible = () => {
      let visible = false;
      const { y, height } = el.getBoundingClientRect();

      if (el.intersect.container === window) {
        visible = y < window.innerHeight && y + height > 0;
      } else {
        const parent = el.parentNode;
        const { y: parentY, height: parentHeight } =
          parent.getBoundingClientRect();
        visible = parentHeight + parentY >= y && y + height >= parentY;
      }

      return visible;
    };

    el.intersect.callback = () => {
      let condition = el.intersect.isVisible();

      if (condition) {
        !el.intersect.visible && binding.value.callback();
        el.intersect.visible = true;
        if (el.intersect.once)
          el.intersect.container.removeEventListener(
            "scroll",
            el.intersect.callback
          );
      } else {
        if (el.intersect.lostVisibility !== null) {
          el.intersect.visible && el.intersect.lostVisibility();
        }
        el.intersect.visible = false;
      }
    };

    if (el.intersect.start) binding.value.callback();

    el.intersect.container.addEventListener("scroll", el.intersect.callback);
  },
  unmounted(el) {
    el.intersect.container.removeEventListener("scroll", el.intersect.callback);
  },
};
