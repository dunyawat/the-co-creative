export default {
  mounted(el, binding) {
    const { modifiers, arg } = binding;

    el.eventElement =
      arg === "window" ? window : arg === "document" ? document : el;

    const keymap = Object.keys(binding.value).map((set) => {
      const keys = set.split("+");
      const combination = {
        hotkey: set,
        key: "",
        altKey: false,
        ctrlKey: false,
        metaKey: false,
      };

      keys.forEach((key) => {
        switch (key) {
          case "ctrl":
            combination.ctrlKey = true;
            break;
          case "alt":
            combination.altKey = true;
            break;
          case "meta":
            combination.metaKey = true;
            break;
          default:
            combination.key = key;
            break;
        }
      });

      return combination;
    });

    el.hotkeyHandler = (event) => {
      modifiers.prevent && event.preventDefault();
      modifiers.stop && event.stopPropagation();

      const { key, altKey, ctrlKey, metaKey } = event;

      keymap.forEach((k, index) => {
        const keyCombination = keymap[index];
        if (
          keyCombination.key.toLowerCase() === key.toLowerCase() &&
          keyCombination.altKey === altKey &&
          keyCombination.ctrlKey === ctrlKey &&
          keyCombination.metaKey === metaKey
        ) {
          binding.value[keyCombination.hotkey]();
        }
      });
    };

    el.eventElement.addEventListener("keydown", el.hotkeyHandler);
  },

  unmounted(el) {
    el.eventElement.removeEventListener("keydown", el.hotkeyHandler);
  },
};
