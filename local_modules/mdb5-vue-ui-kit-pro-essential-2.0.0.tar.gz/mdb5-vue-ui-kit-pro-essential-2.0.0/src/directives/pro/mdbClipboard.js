export default {
  mounted(el, binding) {
    el.copyToClipboard = () => {
      let copyValue;

      if (binding.value) {
        copyValue = binding.value;
      } else if (!binding.value && !binding.instance.value) {
        copyValue = el.textContent;
      } else if (binding.instance.value) {
        copyValue = binding.instance.value.textContent;
      }

      navigator.clipboard.writeText(copyValue);
    };

    el.addEventListener("click", el.copyToClipboard);
  },

  unmounted(el) {
    el.removeEventListener("click", el.copyToClipboard);
  },
};
