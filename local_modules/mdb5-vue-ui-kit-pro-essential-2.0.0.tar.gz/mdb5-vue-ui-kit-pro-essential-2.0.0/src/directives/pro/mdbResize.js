export default {
  mounted(el, binding) {
    if (binding.value.start) {
      binding.value.callback();
    }
    window.addEventListener("resize", binding.value.callback);
  },

  unmounted(el, binding) {
    window.removeEventListener("resize", binding.value.callback);
  },
};
