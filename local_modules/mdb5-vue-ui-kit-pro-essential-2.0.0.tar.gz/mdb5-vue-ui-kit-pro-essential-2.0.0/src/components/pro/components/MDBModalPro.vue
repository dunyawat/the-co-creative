<template>
  <transition
    @enter="enter"
    @after-enter="afterEnter"
    @before-leave="beforeLeave"
    @after-leave="afterLeave"
  >
    <component
      ref="root"
      v-if="isActive"
      :is="tag"
      :class="wrapperClass"
      :style="[
        backdropStyle,
        backdropOverflowStyle,
        backdropPointerEventsStyle,
      ]"
      :aria-hidden="!isActive"
      :aria-modal="isActive ? true : null"
      :aria-labelledby="labelledby"
      role="dialog"
      @click.self="
        () => {
          if (nonInvasive) {
            return;
          }
          if (staticBackdrop) {
            animateStaticBackdrop();
          } else {
            closeModal();
          }
        }
      "
      @show="emitEvent($event, 'show')"
      @shown="emitEvent($event, 'shown')"
      @hide="emitEvent($event, 'hide')"
      @hidden="emitEvent($event, 'hidden')"
    >
      <div :class="[dialogClass, dialogClassPro]" role="document" ref="dialog">
        <div class="modal-content" :style="computedContentStyle">
          <slot></slot>
        </div>
      </div>
    </component>
  </transition>
</template>

<script>
import { computed, ref, watch, watchEffect } from "vue";
import MDBModal from "@/components/free/components/MDBModal";

import useMDBModal from "../../../composables/free/useMDBModal";

import { off } from "../../utils/MDBEventHandlers";

export default {
  name: "MDBModalPro",
  extends: MDBModal,
  props: {
    side: {
      type: Boolean,
      default: false,
    },
    frame: {
      type: [Boolean, String],
      default: false,
    },
    position: {
      type: String,
    },
    nonInvasive: {
      type: Boolean,
      default: false,
    },
    direction: {
      type: String,
      default: "top",
    },
  },
  emits: ["show", "shown", "hide", "hidden", "update:modelValue"],
  setup(props, { emit }) {
    const {
      dialogClass,
      wrapperClass,
      backdropOverflowStyle,
      computedContentStyle,
      root,
      dialog,
      isActive,
      closeModal,
      animateStaticBackdrop,
      afterEnter,
      afterLeave,
      scrollbarWidth,
      shouldOverflow,
      setScrollbar,
      thisElement,
      handleEscKeyUp,
      focusTrap,
      dialogTransform,
    } = useMDBModal(props, emit);

    const dialogClassPro = computed(() => {
      const classes = [];

      props.side && classes.push("modal-side");
      props.frame && classes.push("modal-frame");
      props.position && classes.push(`modal-${props.position}`);
      props.nonInvasive && classes.push("modal-non-invasive-show");

      return classes;
    });

    const value = ref(props.modelValue);
    watchEffect(() => (value.value = props.modelValue));

    watch(
      () => value.value,
      (cur) => {
        emit("update:modelValue", cur);
      }
    );

    // dialog classes - transform

    const dialogTransformPro = computed(() => {
      if (props.direction === "right") {
        return "translate(25%,0)";
      } else if (props.direction === "bottom") {
        return "translate(0,25%)";
      } else if (props.direction === "left") {
        return "translate(-25%,0)";
      }
      return null;
    });

    const emitEvent = (e, eventName) => {
      emit(eventName, e);
    };

    // non invasive modal
    const backdropStyle = computed(() => {
      return props.removeBackdrop || props.nonInvasive
        ? false
        : { "background-color": `rgba(0,0,0, 0.5)` };
    });

    const backdropPointerEventsStyle = computed(() => {
      return props.nonInvasive ? { "pointer-events": "none" } : false;
    });

    const enter = (el) => {
      shouldOverflow.value =
        dialogTransformPro.value === "translate(0,25%)" ? false : true;

      dialogTransform.value = dialogTransformPro.value || "translate(0, -25%)";

      el.childNodes[0].style.transform = dialogTransform.value;
      el.style.opacity = 0;
      el.style.display = "block";

      setScrollbar();

      let onlyModalOpen = !document.body.classList.contains("modal-open");
      let paddingValue = scrollbarWidth.value;
      document.body.style.overflowY = "hidden";

      if (onlyModalOpen && props.nonInvasive) {
        paddingValue = 0;
      }

      if (props.nonInvasive) {
        document.body.style.overflowY = "auto";
      }

      document.body.style.paddingRight = `${paddingValue}px`;
      el.style.paddingRight = `${scrollbarWidth.value}px`;
      document.body.classList.add("modal-open");

      emit("show", root.value);
    };

    const beforeLeave = (el) => {
      el.childNodes[0].style.transform = dialogTransform.value;
      el.style.opacity = 0;
      setTimeout(() => {
        el.style.paddingRight = null;

        if (!props.nonInvasive) {
          document.body.style.paddingRight = null;
          document.body.style.overflowY = "auto";
        }

        document.body.classList.remove("modal-open");
      }, 200);

      emit("hide", thisElement.value);

      if (props.keyboard) {
        off(window, "keyup", handleEscKeyUp);
      }
      if (props.focus && focusTrap.value) {
        focusTrap.value.removeFocusTrap();
      }
    };

    return {
      wrapperClass,
      backdropOverflowStyle,
      computedContentStyle,
      root,
      dialog,
      isActive,
      closeModal,
      animateStaticBackdrop,
      enter,
      afterEnter,
      beforeLeave,
      afterLeave,
      props,
      dialogTransform,
      dialogClass,
      dialogClassPro,
      backdropPointerEventsStyle,
      backdropStyle,
      emitEvent,
      value,
      dialogTransformPro,
      focusTrap,
    };
  },
};
</script>
