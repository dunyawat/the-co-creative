<template>
  <MDBScrollbar
    v-if="scrollContainer"
    :height="scrollElementHeight"
    suppressScrollX
  >
    <component :class="className" :is="tag" v-bind="$attrs" ref="sidenavMenu">
      <slot />
    </component>
  </MDBScrollbar>
  <component
    v-else
    :class="className"
    :is="tag"
    v-bind="$attrs"
    ref="sidenavMenu"
  >
    <slot />
  </component>
</template>

<script>
import { computed, onMounted, provide, reactive, ref } from "vue";
import { MDBScrollbar } from "@/index.pro.js";

export default {
  name: "MDBSideNavMenu",
  inheritAttrs: false,
  components: {
    MDBScrollbar,
  },
  props: {
    tag: {
      type: String,
      default: "ul",
    },
    classes: String,
    accordion: {
      type: Boolean,
      default: false,
    },
    scrollContainer: Boolean,
  },
  setup(props) {
    const className = computed(() => {
      return ["sidenav-menu", props.classes];
    });

    const accordionState = reactive({
      itemsCount: 0,
      active: null,
    });

    const incrementAccordionItemsCount = () => {
      accordionState.itemsCount++;
      return accordionState.itemsCount;
    };

    const setAccordionActiveItem = (item) => {
      accordionState.active = item;
    };

    provide("accordionState", props.accordion ? accordionState : null);
    provide("incrementAccordionItemsCount", incrementAccordionItemsCount);
    provide("setAccordionActiveItem", setAccordionActiveItem);

    onMounted(() => {
      if (props.scrollContainer) {
        setupScrollContent();
      }
    });

    const sidenavMenu = ref("sidenavMenu");
    const scrollElementHeight = ref("100%");

    const setupScrollContent = () => {
      const scrollElement = sidenavMenu.value;
      const siblings = Array.from(
        scrollElement.parentNode.parentNode.children
      ).filter((el) => el !== scrollElement.parentNode);

      const siblingsHeight = siblings.reduce((a, b) => {
        return a + b.clientHeight;
      }, 0);

      scrollElementHeight.value = `calc(100% - ${siblingsHeight}px)`;
    };

    return {
      className,
      sidenavMenu,
      scrollElementHeight,
      props,
    };
  },
};
</script>
