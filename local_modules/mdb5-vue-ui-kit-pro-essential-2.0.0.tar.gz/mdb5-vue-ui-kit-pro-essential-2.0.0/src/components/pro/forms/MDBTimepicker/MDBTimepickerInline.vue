<template>
  <component
    :is="tag"
    ref="modalRef"
    class="timepicker-modal"
    tabindex="-1"
    role="dialog"
  >
    <div
      ref="wrapperRef"
      :class="wrapperClass"
      style="opacity: 1"
      v-mdb-click-outside="handleCancelModal"
      v-mdb-focus-trap
    >
      <div
        class="d-flex align-items-center justify-content-center flex-column shadow timepicker-container"
      >
        <div
          class="d-flex flex-column timepicker-elements justify-content-around timepicker-elements-inline"
        >
          <MDBTimepickerHeader />
        </div>
      </div>
    </div>
  </component>
</template>

<script>
import { computed, inject, onMounted, ref, onBeforeUnmount } from "vue";
import mdbClickOutside from "@/directives/free/mdbClickOutside.js";
import MDBPopper from "@/components/utils/MDBPopper";
import MDBTimepickerHeader from "./MDBTimepickerHeader";
import mdbFocusTrap from "@/directives/free/mdbFocusTrap.js";

export default {
  name: "MDBTimepickerInline",
  components: { MDBTimepickerHeader },
  props: {
    modelvalue: Boolean,
    tag: {
      type: String,
      default: "div",
    },
  },
  directives: {
    mdbClickOutside,
    mdbFocusTrap,
  },
  emits: ["cancel"],
  setup(props, { attrs, emit }) {
    // ------------- REFS -------------
    const modalRef = ref("modalRef");
    const wrapperRef = ref("wrapperRef");

    // ------------- STYLING -------------
    const wrapperClass = computed(() => {
      return [
        "timepicker-wrapper h-100 d-flex align-items-center justify-content-center flex-column timepicker-wrapper-inline",
      ];
    });

    // ------------- POPPER METHODS -------------
    const { setPopper, openPopper, closePopper } = MDBPopper();
    const parentId = inject("inputId", null);
    const dateTimepicker = inject("dateTimepicker", null);

    const fallbackPlacements = ["top", "right", "bottom", "left"];

    const popperSetup = () => {
      let triggerEl;
      if (parentId) {
        triggerEl = document.getElementById(parentId);
      }
      if (dateTimepicker) {
        triggerEl = dateTimepicker.value.inputRef;
      }
      const popperEl = modalRef.value;

      const config = {
        placement: `bottom-start`,
        eventsEnabled: true,
        modifiers: [
          {
            name: "flip",
            options: {
              fallbackPlacements,
            },
          },
          {
            name: "preventOverflow",
            options: {
              boundary: "clippingParent",
            },
          },
        ],
      };

      setPopper(triggerEl, popperEl, config);

      openPopper();
    };

    // ------------- OPENING/CLOSING METHODS -------------
    const handleCancelClick = inject("handleCancelClick", null);

    // prevent handleClose from firing on modal show
    const debounce = ref(false);
    const handleCancelModal = (e) => {
      if (!e.target.closest(".timepicker-modal")) {
        if (debounce.value) {
          emit("cancel");
        }
      }
    };

    // ------------- LIFECYCLE HOOKS -------------
    onMounted(() => {
      popperSetup();
      setTimeout(() => {
        debounce.value = true;
      }, 500);
    });

    onBeforeUnmount(() => {
      closePopper();
    });

    return {
      wrapperRef,
      modalRef,
      wrapperClass,
      handleCancelModal,
      handleCancelClick,
      attrs,
      props,
    };
  },
};
</script>
