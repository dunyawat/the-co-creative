<template>
  <teleport to="body">
    <transition
      name="timepicker-fade"
      @before-enter="beforeEnter"
      @after-leave="afterLeave"
    >
      <component
        :is="tag"
        ref="modalRef"
        class="timepicker-modal"
        tabindex="-1"
        role="dialog"
        v-if="isActive"
      >
        <div
          :class="wrapperClass"
          @click.self="handleClickOutside"
          ref="wrapperRef"
          style="opacity: 1"
          v-mdb-focus-trap
        >
          <div
            class="d-flex align-items-center justify-content-center flex-column shadow timepicker-container"
            ref="timepickerContainerRef"
          >
            <div
              class="d-flex flex-column timepicker-elements justify-content-around"
            >
              <MDBTimepickerHeader />
              <div class="buttons-container" v-if="dateTimepicker">
                <button
                  type="button"
                  class="datepicker-button-toggle"
                  data-mdb-toggle="datepicker"
                  @click="changePicker('datepicker')"
                >
                  <i class="far fa-calendar datepicker-toggle-icon"></i>
                </button>
                <button
                  type="button"
                  class="timepicker-button-toggle"
                  data-mdb-toggle="timepicker"
                >
                  <i class="far fa-clock fa-sm timepicker-icon"></i>
                </button>
              </div>
              <MDBTimepickerPlate />
            </div>
            <MDBTimepickerFooter />
          </div>
        </div>
      </component>
    </transition>
  </teleport>
</template>

<script>
import { computed, inject, ref, watch } from "vue";
import MDBTimepickerFooter from "./MDBTimepickerFooter";
import MDBTimepickerHeader from "./MDBTimepickerHeader";
import MDBTimepickerPlate from "./MDBTimepickerPlate";
import mdbFocusTrap from "@/directives/free/mdbFocusTrap.js";
import { useScrollbarWidth } from "@/components/utils/useScrollbarWidth";

export default {
  name: "MDBTimepickerModal",
  components: {
    MDBTimepickerFooter,
    MDBTimepickerHeader,
    MDBTimepickerPlate,
  },
  directives: {
    mdbFocusTrap,
  },
  props: {
    modelValue: Boolean,
    tag: {
      type: String,
      default: "div",
    },
  },
  emits: ["cancel", "update:modelValue"],
  setup(props, { emit }) {
    // ------------- REFS -------------
    const modalRef = ref(null);
    const wrapperRef = ref(null);

    // ------------- STYLING -------------
    const wrapperClass = computed(() => {
      return [
        "timepicker-wrapper h-100 d-flex align-items-center justify-content-center flex-column position-fixed",
      ];
    });

    // ------------- OPENING/CLOSING METHODS -------------
    const { beforeEnter, afterLeave } = useScrollbarWidth();

    const isActive = ref(props.modelValue);

    const handleClickOutside = () => {
      if (!isActive.value || debounce.value) return;
      isActive.value = false;

      emit("cancel");
      emit("update:modelValue", false);
    };

    const debounce = ref(true);
    watch(
      () => props.modelValue,
      (value) => {
        isActive.value = value;
        setTimeout(() => {
          debounce.value = value;
          setTimeout(() => (debounce.value = !value), 100);
        }, 500);
      }
    );

    const dateTimepicker = inject("dateTimepicker", null);
    const changePicker = inject("changePicker", null);

    return {
      modalRef,
      wrapperRef,
      wrapperClass,
      isActive,
      dateTimepicker,
      changePicker,
      handleClickOutside,
      beforeEnter,
      afterLeave,
    };
  },
};
</script>
