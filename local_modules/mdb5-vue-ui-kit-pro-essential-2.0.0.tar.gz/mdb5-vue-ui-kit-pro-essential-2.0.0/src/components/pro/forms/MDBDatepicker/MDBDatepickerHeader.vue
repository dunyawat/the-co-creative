<template>
  <div class="datepicker-header">
    <div class="datepicker-title">
      <span class="datepicker-title-text">{{ title }}</span>
    </div>
    <div class="datepicker-date">
      <span class="datepicker-date-text"
        >{{ headerWeekday }}, {{ headerMonth }} {{ headerMonthday }}</span
      >
    </div>
    <div class="buttons-container" v-if="dateTimepicker">
      <button
        type="button"
        class="datepicker-button-toggle"
        data-mdb-toggle="datepicker"
      >
        <i class="far fa-calendar datepicker-toggle-icon"></i>
      </button>
      <button
        type="button"
        class="timepicker-button-toggle"
        data-mdb-toggle="timepicker"
        @click="changePicker('timepicker')"
      >
        <i class="far fa-clock fa-sm timepicker-icon"></i>
      </button>
    </div>
  </div>
</template>

<script>
import { inject, computed } from "vue";

export default {
  name: "MDBDatepickerHeader",
  setup() {
    const headerDate = inject("headerDate");
    const weekdaysShort = inject("weekdaysShort");
    const monthsShort = inject("monthsShort");
    const title = inject("title");

    const headerWeekday = computed(() => weekdaysShort[headerDate.value.day()]);
    const headerMonth = computed(() => monthsShort[headerDate.value.month()]);
    const headerMonthday = computed(() => headerDate.value.date());

    const dateTimepicker = inject("dateTimepicker", null);
    const changePicker = inject("changePicker", null);

    return {
      headerWeekday,
      headerMonth,
      headerMonthday,
      title,
      dateTimepicker,
      changePicker,
    };
  },
};
</script>
