<template>
  <teleport to="body">
    <transition-group
      name="datepicker-fade"
      @before-enter="beforeEnter"
      @after-leave="afterLeave"
    >
      <div v-if="isActive" class="datepicker-backdrop"></div>
      <div
        v-if="isActive"
        class="datepicker-modal-container"
        v-mdb-click-outside="handleClickOutside"
      >
        <MDBDatepickerHeader />

        <MDBDatepickerMain />
      </div>
    </transition-group>
  </teleport>
</template>

<script>
import { ref, watch } from "vue";
import mdbClickOutside from "@/directives/free/mdbClickOutside";
import { useScrollbarWidth } from "@/components/utils/useScrollbarWidth";
import MDBDatepickerHeader from "./MDBDatepickerHeader";
import MDBDatepickerMain from "./MDBDatepickerMain";

export default {
  name: "MDBDatepickerModal",
  props: {
    modelValue: Boolean,
  },
  components: {
    MDBDatepickerHeader,
    MDBDatepickerMain,
  },
  directives: {
    mdbClickOutside,
  },
  emits: ["update:modelValue", "cancel"],
  setup(props, { emit }) {
    const { beforeEnter, afterLeave } = useScrollbarWidth();
    const isActive = ref(props.modelValue);

    const handleClickOutside = () => {
      if (!isActive.value || debounce.value) return;
      isActive.value = false;

      emit("cancel");
      emit("update:modelValue", false);
    };

    const debounce = ref(true);
    watch(
      () => props.modelValue,
      (value) => {
        isActive.value = value;
        setTimeout(() => {
          debounce.value = value;
          setTimeout(() => (debounce.value = !value), 100);
        }, 500);
      }
    );

    return {
      isActive,
      handleClickOutside,
      beforeEnter,
      afterLeave,
    };
  },
};
</script>
