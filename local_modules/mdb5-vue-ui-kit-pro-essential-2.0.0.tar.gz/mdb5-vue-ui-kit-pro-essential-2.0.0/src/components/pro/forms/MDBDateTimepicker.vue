<template>
  <MDBInput
    ref="inputRef"
    :label="label"
    v-model="inputValue"
    :wrapperClass="inputWrapperClass"
    v-bind="$attrs"
    :invalidFeedback="invalidLabel"
    :validFeedback="validLabel"
    aria-haspopup="dialog"
    :isValid="valid"
    :isValidated="validated"
    :id="uid"
    :disabled="disabled"
    @click.stop="handleInputToggle"
    @keydown.enter="handleInputToggle"
  >
    <button
      v-if="icon && toggleButton"
      type="button"
      class="datetimepicker-toggle-button"
      aria-haspopup="dialog"
      ref="btnRef"
      @click="toggleDatepicker"
      :disabled="disabled"
    >
      <i :class="customIconClass" /></button
  ></MDBInput>
  <div v-show="false">
    <MDBDatepicker
      v-model="datepickerModel"
      label="Select a date"
      v-bind="datepickerProps"
      ref="datepickerRef"
      @cancel="handleCancel"
      @close="toggleTimepicker"
      v-model:isValidated="isDatepickerValidated"
      v-model:isValid="isDatepickerValid"
    />
    <MDBTimepicker
      v-model="timepickerModel"
      label="Select a time"
      v-bind="timepickerProps"
      ref="timepickerRef"
      v-model:isValidated="isTimepickerValidated"
      v-model:isValid="isTimepickerValid"
    />
  </div>
</template>

<script>
import { ref, computed, watchEffect, watch, toRaw, provide } from "vue";
import { getUID } from "@/components/utils/getUID";

import { MDBDatepicker, MDBInput } from "@/index.pro.js";
import MDBTimepicker from "./MDBTimepicker/MDBTimepicker.vue";

export default {
  name: "MDBDateTimepicker",
  components: {
    MDBTimepicker,
    MDBDatepicker,
    MDBInput,
  },
  props: {
    datepicker: Object,
    defaultTime: String,
    defaultDate: String,
    disabled: Boolean,
    modelValue: {
      type: [String, Date],
    },
    label: String,
    icon: {
      type: Boolean,
      default: true,
    },
    iconClass: {
      type: String,
      default: "far fa-calendar fa-sm",
    },
    id: String,
    inline: Boolean,
    inputToggle: Boolean,
    invalidLabel: {
      type: String,
      default: "Invalid date format",
    },
    isValid: Boolean,
    isValidated: Boolean,
    validLabel: {
      type: String,
    },
    timepicker: Object,
    toggleButton: {
      type: Boolean,
      default: true,
    },
  },
  emits: [
    "update:isValid",
    "update:isValidated",
    "update:modelValue",
    "open",
    "close",
  ],
  setup(props, { emit }) {
    // ------------- REFS -------------
    const datepickerRef = ref(null);
    const timepickerRef = ref(null);
    const inputRef = ref(null);
    const btnRef = ref(null);

    const uid = props.id || getUID("MDBInput-");

    provide("dateTimepicker", inputRef);

    // ------------- STYLING -------------
    const inputWrapperClass = computed(() => {
      return "datetimepicker";
    });
    const customIconClass = computed(() => {
      return ["timepicker-icon", props.iconClass];
    });

    // ------------- STATE MANAGEMENT -------------
    const datepickerModel = ref(
      props.defaultDate || props.modelValue?.split(",")[0]?.trim() || ""
    );
    const timepickerModel = ref(
      props.defaultTime || props.modelValue?.split(",")[1]?.trim() || ""
    );
    const inputValue = computed(() => {
      if (datepickerModel.value && timepickerModel.value) {
        return `${datepickerModel.value}, ${timepickerModel.value}`;
      }

      return "";
    });

    watch(
      () => inputValue.value,
      (cur) => emit("update:modelValue", cur)
    );

    // ------------- HANDLE PICKERS -------------
    const shouldTimepickerOpen = ref(true);
    const timepickerProps = computed(() => {
      return {
        ...toRaw(props.timepicker),
        inline: props.inline,
      };
    });
    const datepickerProps = computed(() => {
      return {
        ...toRaw(props.datepicker),
        inline: props.inline,
      };
    });

    const toggleDatepicker = () => {
      datepickerRef.value.open();
    };

    const toggleTimepicker = () => {
      if (!shouldTimepickerOpen.value) return;
      timepickerRef.value.open();
    };

    const handleCancel = () => {
      shouldTimepickerOpen.value = false;
      setTimeout(() => (shouldTimepickerOpen.value = true), 500);
    };

    const handleInputToggle = () => {
      if (props.inputToggle) {
        toggleDatepicker();
      }
    };

    const changePicker = (picker) => {
      if (picker === "timepicker") {
        datepickerRef.value.close();
      } else if (picker === "datepicker") {
        timepickerRef.value.close();
        setTimeout(() => toggleDatepicker(), 300);
      }
    };

    const open = () => {
      datepickerRef.value.open();
      emit("open");
    };

    const close = () => {
      datepickerRef.value.close();
      timepickerRef.value.close();
      emit("close");
    };

    provide("changePicker", changePicker);

    // ------------- VALIDATION -------------
    const isTimepickerValidated = ref(false);
    const isTimepickerValid = ref(true);

    const isDatepickerValidated = ref(false);
    const isDatepickerValid = ref(true);

    const valid = ref(props.isValid);
    const validated = ref(props.isValidated);

    watchEffect(() => {
      valid.value = props.isValid;
    });
    watchEffect(() => {
      validated.value = props.isValidated;
    });

    watch(
      () => [isTimepickerValid.value, isDatepickerValid.value],
      (cur) => {
        if (
          cur.some((value) => typeof value === "boolean" && value === false)
        ) {
          emit("update:isValid", false);
          setInputsInvalid();
        }

        if (cur.every((value) => !!value)) {
          emit("update:isValid", true);
        }
      },
      { immediate: true }
    );

    watch(
      () => [isTimepickerValidated.value, isDatepickerValidated.value],
      (cur) => {
        if (cur.some((value) => value)) emit("update:isValidated", true);

        if (
          cur.every((value) => typeof value === "boolean" && value === false)
        ) {
          emit("update:isValidated", false);
        }
      },
      { immediate: true }
    );

    const setInputsInvalid = () => {
      if (!validated.value) return;
      datepickerModel.value = isDatepickerValid.value
        ? datepickerModel.value
        : "";
      timepickerModel.value = isTimepickerValid.value
        ? timepickerModel.value
        : "";
    };

    return {
      datepickerRef,
      timepickerRef,
      inputRef,
      btnRef,
      uid,
      inputWrapperClass,
      customIconClass,
      datepickerModel,
      timepickerModel,
      inputValue,
      timepickerProps,
      datepickerProps,
      valid,
      validated,
      isTimepickerValidated,
      isTimepickerValid,
      isDatepickerValidated,
      isDatepickerValid,
      toggleDatepicker,
      toggleTimepicker,
      handleCancel,
      handleInputToggle,
      open,
      close,
    };
  },
};
</script>
